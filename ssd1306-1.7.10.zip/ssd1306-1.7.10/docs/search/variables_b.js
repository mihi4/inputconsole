var searchData=
[
  ['offset',['offset',['../class_adafruit_canvas_ops.html#aa3bc52732d31517596321f0efa40bafe',1,'AdafruitCanvasOps::offset()'],['../class_nano_canvas_ops.html#a0ff1def9b165746092c0c21adf420612',1,'NanoCanvasOps::offset()']]],
  ['oldselection',['oldSelection',['../struct_s_app_menu.html#ad79da4d78c16e3fbbd2e380dc5763275',1,'SAppMenu']]]
];
