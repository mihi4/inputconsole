var searchData=
[
  ['ssd1325_3a_20ssd1325_20control_20functions',['SSD1325: ssd1325 control functions',['../group___s_s_d1325___o_l_e_d___a_p_i.html',1,'']]],
  ['ssd1331_3a_20ssd1331_20control_20functions',['SSD1331: ssd1331 control functions',['../group___s_s_d1331___a_p_i.html',1,'']]]
];
