var searchData=
[
  ['initfunction',['InitFunction',['../nano__gfx__types_8h.html#aeb51e8c3a40de7886cdc7d9c74175f05',1,'nano_gfx_types.h']]]
];
