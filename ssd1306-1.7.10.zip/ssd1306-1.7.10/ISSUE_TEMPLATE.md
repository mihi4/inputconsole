Please provide the following information:
## library version
## LCD display type
## Steps to reproduce the issue
## Expected behavior
## Actual behavior

